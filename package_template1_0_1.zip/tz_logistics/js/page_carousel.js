
+function ($) {
    $(document).ready(function () {
        $('.tz-carousel .tz-carousel-inner').each(function (index) {
            var item_lg = $(this).attr('data-item-lg'),
                item_md = $(this).attr('data-item-md'),
                item_sm = $(this).attr('data-item-sm'),
                item_xs = $(this).attr('data-item-xs'),
                smart_speed = $(this).attr('data-smart-speed'),
                data_center = $(this).attr('data-center'),
                data_id = $(this).attr('data-id'),
                data_margin_item = $(this).attr('data-margin'),
                data_navText_left = $(this).attr('data-navText-left'),
                data_navText_right = $(this).attr('data-navText-right'),
                data_dots = $(this).attr('data-dots'),
                data_nav = $(this).attr('data-nav'),
                data_animation_out = $(this).attr('data-animation-out'),
                loop = $(this).attr('data-item-lg');
            if (data_dots === '0') {
                data_dots = false;
            } else {
                data_dots = true;
            }
            if (data_nav === '0') {
                data_nav = false;
            } else {
                data_nav = true;
            }
            if (data_center === '0') {
                data_center = false;
            } else {
                data_center = true;
            }
            $(this).owlCarousel({
                loop: true,
                margin: parseInt(data_margin_item),
                nav: data_nav,
                dots: data_dots,
                animateOut: 'fadeOut',
                animateIn: 'fadeIn',
                mouseDrag: false,
                smartSpeed: smart_speed,
                navText: [data_navText_left, data_navText_right],
                center: data_center,
                responsive: {
                    0: {
                        items: item_xs
                    },
                    767: {
                        items: item_sm
                    },
                    991: {
                        items: item_md
                    },
                    1200: {
                        items: item_lg
                    }
                },
                onInitialized: function () {
                    if (data_center == '1') {
                        $('[data-id="' + data_id + '"] .owl-item.active').first().addClass('text-right');
                        $('[data-id="' + data_id + '"] .owl-item.active').last().addClass('text-left');
                    }
                },
                onTranslated: function () {
                    if (data_center == '1') {
                        $('[data-id="' + data_id + '"] .owl-item.active').removeClass('text-right text-left');
                        $('[data-id="' + data_id + '"] .owl-item.active').first().addClass('text-right');
                        $('[data-id="' + data_id + '"] .owl-item.active').last().addClass('text-left');
                    }
                }
            });
        });

        $('.tz-owl-carousel').each(function (index) {
            var data_plugin_option = $(this).data('plugin-options');
            $(this).owlCarousel(
                data_plugin_option
            );
        });

    });
}(jQuery);
