jQuery(window).load(function() {
	jQuery(document).find('body').addClass('loaded');
});
