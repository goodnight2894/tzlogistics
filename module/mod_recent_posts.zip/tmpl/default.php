<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_category
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

if(!function_exists('getCRTItem')) {// loop delete
	function getCRTItem($id) {

		$db = JFactory::getDbo(); // connect database
		$query = $db->getQuery(true);
		$query->select('images')
			->select('introtext')
			->from('#__content')
			->where('id = ' . (int) $id);
		$db->setQuery($query);


		$crt_item = $db->loadObject();


		return $crt_item;
	}
}


$doc        = JFactory::getDocument();
$template   = $app->getTemplate();

$dot =  $params->get('show_dot');
$show_infinite = $params->get('show_infinite');
$gn_speed = $params->get('gn_speed');
$slidestoshow = $params->get('slidesToShow');
$slidestocroll = $params->get('slidesToScroll');
$slidesToShow_tb = $params->get('slidesToShow_tb');
$slidesToScroll_tb = $params->get('slidesToScroll_tb');
$slidesToShow_mb = $params->get('slidesToShow_mb');
$slidesToScroll_mb = $params->get('slidesToScroll_mb');
$slidesToShow_smb = $params->get('slidesToShow_smb');
$slidesToScroll_smb = $params->get('slidesToScroll_smb');
$title = $params->get('title');


?>
<div class="latest category-module<?php echo $module->id;?> tz_recent_posts  <?php echo $moduleclass_sfx; ?> `">
    <div class="row">
        <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 ">
            <div class="latest__content">
                <?php if($title !=''):?>
                    <div class="title__primary-x2">
                        <?php echo $title;?>
                    </div>
                <?php endif;?>
                <div class="latest__content<?php echo $module->id;?>">
                    <?php foreach ($list as $item) : ?>
                        <div class="latest__box-item">
                            <div class="latest__recen-date">
                                <div class="latest__date">
                                    <?php if ($item->displayoneDate) : ?>
                                        <span class="mod-recent-date">
                                        <?php echo $item->displayoneDate;?>
                                    </span>
                                    <?php endif; ?>
                                    <?php if ($item->displayMon) : ?>
                                        <span class="mod-recent-mon">
                                        <?php echo $item->displayMon;?>
                                    </span>
                                    <?php endif; ?>

                                </div>
                            </div>
                            <div class="latest__recent-content">
                                <?php if ($params->get('link_titles') == 1) : ?>
                                    <h3 class="mod-articles-category-title <?php echo $item->active; ?>">
                                        <a  href="<?php echo $item->link; ?>">
                                            <?php echo $item->title; ?>
                                        </a>
                                    </h3>
                                <?php else : ?>
                                    <?php echo $item->title; ?>
                                <?php endif; ?>

                                <?php if ($item->displayHits) : ?>
                                    <span class="mod-articles-category-hits">
                                        (<?php echo $item->displayHits; ?>)
                                    </span>
                                <?php endif; ?>
                                <?php if ($item->displayCategoryTitle) : ?>
                                    <span class="mod-articles-category-category">
                                        (<?php echo $item->displayCategoryTitle; ?>)
                                    </span>
                                <?php endif; ?>
                                <?php if ($params->get('show_introtext')) : ?>
                                    <p class="mod-articles-category-introtext">
                                        <?php echo $item->displayIntrotext; ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($params->get('show_readmore')) : ?>
                                    <p class="mod-articles-category-readmore">
                                        <a class="mod-articles-category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
                                            <?php if ($item->params->get('access-view') == false) : ?>
                                                <?php echo JText::_('MOD_ARTICLES_CATEGORY_REGISTER_TO_READ_MORE'); ?>
                                            <?php elseif ($readmore = $item->alternative_readmore) : ?>
                                                <?php echo $readmore; ?>
                                                <?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
                                            <?php elseif ($params->get('show_readmore_title', 0) == 0) : ?>
                                                <?php echo JText::sprintf('MOD_ARTICLES_CATEGORY_READ_MORE_TITLE'); ?>
                                            <?php else : ?>
                                                <?php echo JText::_('MOD_ARTICLES_CATEGORY_READ_MORE'); ?>
                                                <?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
                                            <?php endif; ?>
                                        </a>
                                    </p>
                                <?php endif; ?>
                                <?php if ($params->get('show_author')) : ?>
                                    <span class="mod-recent-writtenby">
                                        <?php echo 'by '.$item->displayAuthorName; ?>
                                    </span>
                                <?php endif;?>
                                <?php if ($item->displayDate) : ?>
                                    <span class="mod-recent-date">
                                        <i class="fa fa-calendar"></i><?php echo $item->displayDate; ?>
                                    </span>
                                <?php endif; ?>
                                <div class="latest__read-more">
                                    <a href="<?php echo $item->link;?>"><?php echo JText::_('MOD_ARTICLES_TZ_READ_MORE')?></a>
                                </div>

                            </div>
                        </div>
                    <?php endforeach; ?>

                </div>
                <div class="custom-navigation">
                    <span class=" latest__next tz_next<?php echo $module->id;?>">
                        <i class="fa fa-angle-left " aria-hidden="true"></i>
                    </span>
                    <span class="latest__pre tz_prev<?php echo $module->id;?>">
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                    </span>
                </div>

            </div>
        </div>
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 ">
            <div class="latest__image latest__image<?php echo $module->id;?>">
                <?php foreach ($list as $item) :
                    $obj_crt_img =getCRTItem($item->id);
                    $crt_img = $obj_crt_img->images;
                    $img = json_decode($crt_img);
                    $imagesb = $img->image_intro;
                    ?>
                    <div class="latest__respodiver-image">
                        <img src="<?php echo $imagesb;?>" alt=""/>
                    </div>

                <?php endforeach; ?>
            </div>
        </div>

    </div>
</div>


<script>


	jQuery('.latest__content<?php echo $module->id;?>').slick({
		dots: false,
		infinite: <?php echo $show_infinite;?>,
		slidesToShow: 1,
        asNavFor: '.latest__image<?php echo $module->id;?>',
		fade: true,
        prevArrow: jQuery('.tz_prev<?php echo $module->id;?>'),
        nextArrow: jQuery('.tz_next<?php echo $module->id;?>'),
		slidesToScroll: 1
	});
    jQuery('.latest__image<?php echo $module->id;?>').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        dots: false,
        centerMode: false,
        focusOnSelect: true,
        touchMove: false,
        draggable: false,
        asNavFor: '.latest__content<?php echo $module->id;?>'
    });

</script>