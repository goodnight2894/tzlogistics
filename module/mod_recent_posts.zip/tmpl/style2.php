<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_category
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

if(!function_exists('getCRTItem')) {// loop delete
    function getCRTItem($id) {

        $db = JFactory::getDbo(); // connect database
        $query = $db->getQuery(true);
        $query->select('images')
            ->select('introtext')
            ->from('#__content')
            ->where('id = ' . (int) $id);
        $db->setQuery($query);


        $crt_item = $db->loadObject();


        return $crt_item;
    }
}


$doc        = JFactory::getDocument();
$template   = $app->getTemplate();


$doc->addStyleSheet('templates/'.$template.'/js/prettyphoto/css/prettyPhoto.css');
$doc->addScript('templates/'.$template.'/js/prettyphoto/js/jquery.prettyPhoto.js');

?>
<div class="tz_recent_blog_meetup">
<div class="row">

        <?php foreach ($list as $i => $item) :
            $a = $i++;
            $obj_crt_img =getCRTItem($item->id);
            $crt_img = $obj_crt_img->images;
            $img = json_decode($crt_img);
            $imagesb = $img->image_intro;

            $class1 = '';
            $class2 = '';
            if($a % 4){
                $class2= 'tz_recent_blog_list ';
            }

            if($a <= 3):
            ?>
            <?php if($a % 4 == 0): ?>
                 <?php $class1= 'tz_recent_blog_meetup_content'; ?>
                     <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <?php elseif($a % 4 == 1):?>

                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <?php endif;?>
                <div class="tz_recent_blog_meetup_content <?php echo $class2;?>">
                    <div class="recen_box <?php echo $class1;?> ">
                        <img src="<?php echo $imagesb;?>" alt=""/>
                        <div class="mod-recent_link">
                            <div class="ds-table">
                                <div class="ds-table-cell">
                                    <a href="<?php echo  $imagesb;?>" data-rel="prettyPhoto"><i class="fa fa-search"></i></a>
                                    <a href="<?php echo $item->link;?>"><i class="fa fa-external-link"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="meetup_date">
                            <?php if ($item->displayMon) : ?>
                                <span class="mod-recent-mon">
                                <?php echo $item->displayMon;?>
                            </span>
                            <?php endif; ?>
                            <?php if ($item->displayoneDate) : ?>
                                <span class="mod-recent-date">
                                <?php echo $item->displayoneDate;?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mod_recent_content ">
                        <?php if ($params->get('link_titles') == 1) : ?>
                            <h4 class="mod-articles-category-title <?php echo $item->active; ?>">
                                <a  href="<?php echo $item->link; ?>">
                                    <?php echo $item->title; ?>
                                </a>
                            </h4>
                        <?php else : ?>
                            <?php echo $item->title; ?>
                        <?php endif; ?>

                        <?php if ($item->displayHits) : ?>
                            <span class="mod-articles-category-hits">
                                (<?php echo $item->displayHits; ?>)
                            </span>
                        <?php endif; ?>
                        <?php if ($item->displayCategoryTitle) : ?>
                            <span class="mod-articles-category-category">
                                (<?php echo $item->displayCategoryTitle; ?>)
                            </span>
                        <?php endif; ?>
                        <?php if ($params->get('show_introtext')) : ?>
                            <p class="mod-articles-category-introtext">
                                <?php echo $item->displayIntrotext; ?>
                            </p>
                        <?php endif; ?>
                        <?php if ($params->get('show_readmore')) : ?>
                            <p class="mod-articles-category-readmore">
                                <a class="mod-articles-category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
                                    <?php if ($item->params->get('access-view') == false) : ?>
                                        <?php echo JText::_('MOD_ARTICLES_CATEGORY_REGISTER_TO_READ_MORE'); ?>
                                    <?php elseif ($readmore = $item->alternative_readmore) : ?>
                                        <?php echo $readmore; ?>
                                        <?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
                                    <?php elseif ($params->get('show_readmore_title', 0) == 0) : ?>
                                        <?php echo JText::sprintf('MOD_ARTICLES_CATEGORY_READ_MORE_TITLE'); ?>
                                    <?php else : ?>
                                        <?php echo JText::_('MOD_ARTICLES_CATEGORY_READ_MORE'); ?>
                                        <?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
                                    <?php endif; ?>
                                </a>
                            </p>
                        <?php endif; ?>
                        <?php if ($params->get('show_author')) : ?>
                            <span class="mod-recent-writtenby">
                                <?php echo 'by '.$item->displayAuthorName; ?>

                            </span>
                        <?php endif;?>
                        <?php if ($item->displayDate) : ?>
                            <span class="mod-recent-date" >
                                <i class="fa fa-calendar"></i><?php echo $item->displayDate; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
             <?php if($a % 4 == 0): ?>
                 </div>
             <?php elseif($a % 4 == 3):?>
                </div>
            <?php endif;?>
        <?php
            endif;
        endforeach; ?>

</div>
</div>

<script>
    jQuery(document).ready(function(){
        jQuery(".tz_recent_blog_meetup li a[data-rel^='prettyPhoto']").prettyPhoto();
    });



</script>