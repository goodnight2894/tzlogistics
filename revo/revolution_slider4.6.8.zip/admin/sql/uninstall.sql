DROP TABLE IF EXISTS `#__revslider_sliders`;
DROP TABLE IF EXISTS `#__revslider_slides`;
DROP TABLE IF EXISTS `#__revslider_settings`;
DROP TABLE IF EXISTS `#__revslider_css`;
DROP TABLE IF EXISTS `#__revslider_layer_animations`;