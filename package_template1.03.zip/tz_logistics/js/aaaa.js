/**
 * Created by TuanMap on 05/09/2017.
 */
$(document).ready(function () {
    okno.init();

    var $header = $('.tz__header'),
        $navBar = $('#nav-bar'),
        headerHeight = $header.height(),
        stickyBarrier = $(window).height() - $navBar.height() - 2,
        outBarrier = $header.height() * 2,
        scrolled = 0;
    window.setHeader = function () {

        scrolled = $(window).scrollTop();
        // console.log(scrolled,$header.height());
        if (scrolled > headerHeight && !$header.hasClass('fixed')) {
            $header.addClass('fixed,sticky');
            if (!$header.hasClass('absolute')) {
                $body.css('padding-top', headerHeight + 'px');
            }
        } else if (scrolled <= headerHeight && $header.hasClass('fixed')) {
            $header.removeClass('fixed,sticky');
            if (!$header.hasClass('absolute')) {
                $body.css('padding-top', 0);
            }
        }

        if (scrolled > outBarrier && !$header.hasClass('out')) {
            $header.addClass('out');
        } else if (scrolled <= outBarrier && $header.hasClass('out')) {
            $header.removeClass('out');
        }

        if (scrolled > stickyBarrier && !$header.hasClass('sticky')) {
            $header.addClass('sticky');
            $body.addClass('sticky-header');
        } else if (scrolled <= stickyBarrier && $header.hasClass('sticky')) {
            $header.removeClass('sticky');
            $body.removeClass('sticky-header');
        }
    };

    $('ul.main-menu-agency li a').on('click', function () {
        $("body").removeClass("side-panel-open");
    });
    $(window).scroll(function () {
        setHeader();
    });
    var $nav = $('.scroll-onepage .plazart-mainnav,.main-menu-agency');
    $nav.onePageNav({
        currentClass: 'current',
        changeHash: false,
        scrollSpeed: 2200,
        scrollOffset: 0,
        scrollThreshold: 0.5,
        filter: '',
        heightNav: jQuery('.header-menu').height()

    });
});