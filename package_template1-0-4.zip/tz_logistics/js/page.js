
(function ($) {
    $(window).load(function() {
        $(document).find('body').addClass('loaded');
    });
	$(document).ready(function () {
        if ($('.right-menu').length > 0) {

            $('.right-menu a.search_icon').on('click', function () {
                $('.logistics-menu .search').toggleClass("open");

            });

        }

    });
})(jQuery);