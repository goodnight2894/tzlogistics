<?php defined('_JEXEC') or die; ?>
<div class="container">
    <hr />
    <div class="framework-logo">
        <p class="pull-right">
            Based on <a href="http://www.templaza.com/">Plazart Framework</a>
        </p>
        <p>
            &copy; <?php echo date('Y'); ?> <?php echo JFactory::getApplication()->get('sitename'); ?>
        </p>
    </div>
</div>
