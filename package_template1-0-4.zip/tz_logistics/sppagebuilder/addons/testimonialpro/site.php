<?php
/**
 * @package SP Page Builder
 * @author JoomShaper http://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2016 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/
//no direct accees
defined ('_JEXEC') or die ('restricted aceess');

class SppagebuilderAddonTestimonialpro extends SppagebuilderAddons {

	public function render() {

		$class = (isset($this->addon->settings->class) && $this->addon->settings->class) ? $this->addon->settings->class : '';
		$style = (isset($this->addon->settings->style) && $this->addon->settings->style) ? $this->addon->settings->style : '';

		//Options
		$autoplay = (isset($this->addon->settings->autoplay) && $this->addon->settings->autoplay) ? ' data-sppb-ride="sppb-carousel"' : '';
		$arrows = (isset($this->addon->settings->arrows) && $this->addon->settings->arrows) ? $this->addon->settings->arrows : '';

        $style_testimonialpro = (isset($this->addon->settings->style_testimonialpro) && $this->addon->settings->style_testimonialpro) ? $this->addon->settings->style_testimonialpro : '';
		$controls = (isset($this->addon->settings->controls) && $this->addon->settings->controls) ? $this->addon->settings->controls : 0;
		$interval = (isset($this->addon->settings->interval) && $this->addon->settings->interval) ? ((int) $this->addon->settings->interval * 1000) : 5000;

		if($style_testimonialpro == 'basic'){
            $output  = '<div id="sppb-testimonial-pro-'. $this->addon->id .'" data-interval="'.$interval.'" class="sppb-carousel sppb-testimonial-pro sppb-slide sppb-text-center' . $class . '"'. $autoplay .'>';

            if($controls) {
                $output .= '<ol class="sppb-carousel-indicators">';
                foreach ($this->addon->settings->sp_testimonialpro_item as $key1 => $value) {
                    $output .= '<li data-sppb-target="#sppb-carousel-'. $this->addon->id .'" '. (($key1 == 0) ? ' class="active"': '' ) .'  data-sppb-slide-to="'. $key1 .'"></li>' . "\n";
                }
                $output .= '</ol>';
            }

            $output .= '<div class="sppb-carousel-inner">';

            foreach ($this->addon->settings->sp_testimonialpro_item as $key => $value) {
                $output   .= '<div class="sppb-item ' . (($key == 0) ? ' active' : '') .'">';
                $title = '<strong class="pro-client-name">'. $value->title .'</strong>';

                if($value->url) $title .= ' - <span class="pro-client-url">'. $value->url .'</span>';
                if($value->avatar) $output .= '<img class="sppb-img-responsive sppb-avatar '. $value->avatar_style .'" src="'. $value->avatar .'" alt="">';
                $output  .= '<div class="sppb-testimonial-message">' . $value->message . '</div>';
                if($title) $output .= '<div class="sppb-testimonial-client">' . $title . '</div>';

                $output  .= '</div>';
            }
            $output	.= '</div>';

            if($arrows) {
                $output	.= '<a href="#sppb-testimonial-pro-'. $this->addon->id .'" class="left sppb-carousel-control" data-slide="prev"><i class="fa fa-angle-left"></i></a>';
                $output	.= '<a href="#sppb-testimonial-pro-'. $this->addon->id .'" class="right sppb-carousel-control" data-slide="next"><i class="fa fa-angle-right"></i></a>';
            }
            $output .= '</div>';
        }else{

            $output = '<div  class="testimonial">';
            $output .= '<div  class="quote">';
            $output .= '
                        <span class="fa-stack fa-lg">
                             <i class="fa fa-comment  fa-stack-2x" aria-hidden="true"></i>
                                <i class="fa fa-quote-right fa-stack-1x" ></i>
                        </span>
                        ';

            $output .= '</div>';
            $output .= '<div id="slider'. $this->addon->id .'" class="flexslider testimonial__slider-nav">';
		    $output .='<ul class="slider-for'. $this->addon->id .'">';
            foreach ($this->addon->settings->sp_testimonialpro_item as $key => $value) {
                $output .= '<li>';
                $output .= '<div class="testimonial__tz-carousel-inner">';
                $output .= '<div class="testimonial__tz-message">' . $value->message . '</div>';


                $output .= '</div>';
                $output .= '</li>';
            }
            $output .='</ul>';
            $output .='</div>';
            $output .= '<div id="carousel'. $this->addon->id .'" class="flexslider testimonial__slider-for">';
            $output .='<ul class="slider-nav'. $this->addon->id .'">';
            foreach ($this->addon->settings->sp_testimonialpro_item as $key => $value) {
                $title = '<h6 class="testimonial__pro-client-name">'. $value->title .'</h6>';
                $output .= '<li>';
                $output .= '<div class="testimonial__img-responsive">';
                if($value->avatar) $output .= '<img class="tz-img-responsive sppb-avatar '. $value->avatar_style .'" src="'. $value->avatar .'" alt="">';
                $output .= '</div>';
                if($value->url) $title .= '<span class="tz-client-url">'. $value->url .'</span>';
                if($title) $output .= '<div class="testimonial__tz-client">' . $title . '</div>';
                $output .= '</li>';
            }

            $output .='</ul>';
            $output .='</div>

                <div class="custom-navigation">
                    <span class=" testimonial__next tz_next">
                        <i class="fa fa-angle-left " aria-hidden="true"></i>
                    </span>
                    <span class="testimonial__pre tz_prev">
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                    </span>
                </div>
            ';
            $output .='</div> ';
        }


		//Output


		return $output;

	}

	public function css() {
		$addon_id = '#sppb-addon-' . $this->addon->id;
		$css = '';

		$speed = (isset($this->addon->settings->speed) && $this->addon->settings->speed) ? $this->addon->settings->speed : 600;

		$css .= $addon_id.' .sppb-carousel-inner > .sppb-item{-webkit-transition-duration: '.$speed.'ms; transition-duration: '.$speed.'ms;}';

		return $css;
	}
    public function js() {
        $addon_id =  $this->addon->id;
        $js = "jQuery(function($){

            jQuery('.slider-for$addon_id').slick({
              slidesToShow: 1,
              dots: false,
              slidesToScroll: 1,
              arrows: false,
              fade: true,
              asNavFor: '.slider-nav$addon_id'
            });
            jQuery('.slider-nav$addon_id').slick({
              dots: false,
              slidesToShow: 3,
              slidesToScroll: 1,
              asNavFor: '.slider-for$addon_id',
              prevArrow: jQuery('.tz_prev'),
              nextArrow: jQuery('.tz_next'),
              dots: false,
              centerMode: true,
              focusOnSelect: true
            });



		})";


        return $js;
    }
}
