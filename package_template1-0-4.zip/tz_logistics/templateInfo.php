<?php
// no direct access
defined('_JEXEC') or die;
?>

<div class="span4">
  <div class="tpl-preview">
    <img src="<?php echo PLAZART_TEMPLATE_URL ?>/template_preview.png" alt="Template Preview" />
  </div>
</div>
<div class="span8">
  <div class="overview-header">
  	<h2>
      TZ Logistics
      <small style="display: block;">Your solid Starting Point</small>
    </h2>
    <p>Logistic is a popular and leading template for transport, cargo logistics Joomla websites for industries that face in shipping, delivery and storage services.</p>
    <p>
        Thanks to Plazart Framework, TZ Portfolio Plus with addons and template style, JSN Uniform, SP Page Buillder and many others bring us various features, highly responsiveness and ease of use.</p>
  </div>
  <div class="overview-body">
    <h4>Quick Features</h4>
    <ul class="overview-features">
      <li>Clean and semantic CSS/HTML base.</li>
      <li>Smart workflow</li>
      <li>Build with LESS</li>
    </ul>
  </div>
</div>

