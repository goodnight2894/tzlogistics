<?php
/**
 * @package   Plazart Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

$doc = JFactory::getDocument();
$renderer = $doc->loadRenderer('modules');
$position = 'tz-right-menu';
$options = array('style' => 'raw');
$top_right = $renderer->render($position,$options,null);


?>
<!-- MAIN NAVIGATION -->


<nav id="plazart-mainnav" class="wrap plazart-mainnav navbar">
    <div class="navbar-inner">
    <?php

    if(isset($top_right) && $top_right != ''){
        echo '<div class="right-menu pull-right">';
        echo '<a href="javascript:void(0)" class="search_icon"><i class="fa fa-search js-search"></i></a>';
        echo  $top_right;
        echo '</div>';
    }

    ?>
      <div class="navbar-header">
      <button type="button" class="btn btn-navbar navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
        <i class="fa fa-bars"></i>
      </button>
      </div>
  	  <div class="nav-collapse navbar-collapse collapse">
      <?php if ($this->getParam('navigation_type','megamenu') == 'megamenu') : ?>
        <?php $this->megamenu($this->getParam('mm_type', 'mainmenu')) ?>
      <?php endif; ?>
      </div>
    </div>
</nav>
<!-- //MAIN NAVIGATION -->